

<template>
  <CardComponent title="Cliente">
    <FormComponent>
      <input v-model="cliente.direccion" placeholder="Dirección" class="input" />
      <input v-model="cliente.telefono" placeholder="Teléfono" class="input" />
    </FormComponent>
  </CardComponent>
</template>

<script setup>
import CardComponent from '../components/CardComponent.vue';
import FormComponent from '../components/FormComponent.vue';
import { reactive } from 'vue';

const cliente = reactive({ direccion: '', telefono: '' });
</script>