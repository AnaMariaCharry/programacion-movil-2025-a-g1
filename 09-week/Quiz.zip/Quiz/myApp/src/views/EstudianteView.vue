

<template>
  <CardComponent title="Estudiante">
    <FormComponent>
      <input v-model="estudiante.carrera" placeholder="Carrera" class="input" />
      <input v-model="estudiante.semestre" placeholder="Semestre" class="input" />
    </FormComponent>
  </CardComponent>
</template>

<script setup>
import CardComponent from '../components/CardComponent.vue';
import FormComponent from '../components/FormComponent.vue';
import { reactive } from 'vue';

const estudiante = reactive({ carrera: '', semestre: '' });
</script>