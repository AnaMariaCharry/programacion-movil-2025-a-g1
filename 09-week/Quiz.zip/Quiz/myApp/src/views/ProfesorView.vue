

<template>
  <CardComponent title="Profesor">
    <FormComponent>
      <input v-model="profesor.materia" placeholder="Materia" class="input" />
      <input v-model="profesor.experiencia" placeholder="Años de Experiencia" class="input" />
    </FormComponent>
  </CardComponent>
</template>

<script setup>
import CardComponent from '../components/CardComponent.vue';
import FormComponent from '../components/FormComponent.vue';
import { reactive } from 'vue';

const profesor = reactive({ materia: '', experiencia: '' });
</script>