

<template>
  <CardComponent title="Proveedor">
    <FormComponent>
      <input v-model="proveedor.empresa" placeholder="Empresa" class="input" />
      <input v-model="proveedor.producto" placeholder="Producto" class="input" />
    </FormComponent>
  </CardComponent>
</template>

<script setup>
import CardComponent from '../components/CardComponent.vue';
import FormComponent from '../components/FormComponent.vue';
import { reactive } from 'vue';

const proveedor = reactive({ empresa: '', producto: '' });
</script>