import { createRouter, createWebHistory } from '@ionic/vue-router';
import { RouteRecordRaw } from 'vue-router';
import HomePage from '../views/HomePage.vue'
import ClienteView from '../views/ClienteView.vue'
import EstudianteView from '../views/EstudianteView.vue'
import ProfesorView from '../views/ProfesorView.vue'
import ProveedorView from '../views/ProveedorView.vue'
import CardComponent from '../components/CardComponent.vue';
import FormComponent from '../components/FormComponent.vue'






const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'Home',
    component: HomePage
  },
  {
    path: '/',
    redirect: '/cliente'
  },
  {
    path: '/cliente',
    name: 'cliente',
    component: ClienteView
  },
  {
    path: '/',
    redirect: '/profesor'
  },
  {
    path: '/profesor',
    name: 'profesor',
    component: ProfesorView
  }
,
  {
    path: '/',
    redirect: '/estudiante'
  },
  {
    path: '/estudiante',
    name: 'estudiante',
    component: EstudianteView
  }
  ,
  {
    path: '/',
    redirect: '/proveedor'
  },
  {
    path: '/proveedor',
    name: 'proveedor',
    component: ProveedorView
  },
  {
    path: '/',
    redirect: '/cardcomponent'
  },
  {
    path: '/cardcomponent',
    name: 'cardcomponent',
    component: CardComponent
  },
  {
    path: '/',
    redirect: '/proveedor'
  },
  {
    path: '/formcomponent',
    name: 'formcomponent',
    component: FormComponent
  }

]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

export default router
