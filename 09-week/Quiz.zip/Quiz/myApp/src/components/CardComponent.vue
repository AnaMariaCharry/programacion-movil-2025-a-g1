<template>
  <div class="p-4 border rounded-lg shadow-md bg-white">
    <h2 class="text-lg font-bold">{{ title }}</h2>
    <slot></slot>
  </div>
</template>

<script setup>
defineProps({ title: String });
</script>
