<template>
  <form class="bg-white shadow-lg rounded-lg p-6 space-y-4 w-96 mx-auto">
  
    
    <input v-model="form.nombre" placeholder="Nombre" class="input" />
    <input v-model="form.apellido" placeholder="Apellido" class="input" />
    <input v-model="form.edad" type="number" placeholder="Edad" class="input" />
    <input v-model="form.correo" type="email" placeholder="Correo" class="input" />
    
    <slot></slot>
    
    <div class="flex flex-wrap justify-center gap-2">
      <button @click.prevent="$emit('agregar')" class="btn btn-blue">Agregar</button>
      <button @click.prevent="$emit('modificar')" class="btn btn-yellow">Modificar</button>
      <button @click.prevent="$emit('eliminar')" class="btn btn-red">Eliminar</button>
      <button @click.prevent="$emit('consultar')" class="btn btn-green">Consultar</button>
    </div>
  </form>
</template>

<script setup>
import { reactive } from 'vue';

const form = reactive({ nombre: '', apellido: '', edad: '', correo: '' });
</script>

<style scoped>
/* Estilos generales */
.input {
  border: 1px solid #ccc;
  padding: 10px;
  width: 100%;
  border-radius: 6px;
  font-size: 16px;
  outline: none;
  transition: border 0.3s;
}
.input:focus {
  border-color: #007bff;
}

/* Botones */
.btn {
  padding: 10px 15px;
  border-radius: 6px;
  color: white;
  font-weight: bold;
  transition: background 0.3s, transform 0.2s;
}
.btn:hover {
  transform: scale(1.05);
}
.btn-blue { background-color: #007bff; }
.btn-blue:hover { background-color: #0056b3; }

.btn-yellow { background-color: #ffc107; }
.btn-yellow:hover { background-color: #d39e00; }

.btn-red { background-color: #dc3545; }
.btn-red:hover { background-color: #a71d2a; }

.btn-green { background-color: #28a745; }
.btn-green:hover { background-color: #1e7e34; }
</style>
